//
//  VenuesVC.swift
//  diningApp
//
//  Created by Angela Lin on 9/20/20.
//  Copyright © 2020 Angela Lin. All rights reserved.
//

import UIKit
import Kingfisher

class VenuesVC: UITableViewController {
    
    var venues = [Venue]()
    var retailVenues = [Venue]()
    var retailVenuePics = [UIImage?]()
    var diningVenues = [Venue]()
    var diningVenuePics = [UIImage?]()
    var venuesCategorized = [[Venue]]()
    var venuePicsCategorized = [[UIImage?]]()
    let headerTitles = ["Dining Halls", "Retail Dining"]
    
    override func viewDidLoad() {
        super.viewDidLoad()


        tableView.estimatedRowHeight = 80

        startNetworkCall()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.estimatedRowHeight = 80
    }
    
    //makes the network call
    func startNetworkCall(){
        print("starting request")
        NetworkManager.networkRequest(){
            (newVenues) in for venue in newVenues{
                print("in network call")
                let name = venue.name
                let dailyMenuURL = venue.dailyMenuURL
                let facilityURL = venue.facilityURL
                let venueType = venue.venueType
                let imageURL1 = venue.imageURL
                let weeklyMenuURL = venue.weeklyMenuURL
                let id = venue.id
                let dateHours = venue.dateHours
                
                if(venueType == "residential"){
                    self.diningVenues.append(Venue(name : name, dailyMenuURL : dailyMenuURL, weeklyMenuURL : weeklyMenuURL, dateHours : dateHours, facilityURL : facilityURL, imageURL : imageURL1, id : id, venueType : venueType))
                }else{
                     self.retailVenues.append(Venue(name : name, dailyMenuURL : dailyMenuURL, weeklyMenuURL : weeklyMenuURL, dateHours : dateHours, facilityURL : facilityURL, imageURL : imageURL1, id : id, venueType : venueType))
                }
                
            }
            //populates a 2D array with the respective dining and retail venues which will designate the sections of the UI
            self.venuesCategorized.append(self.diningVenues)
            self.venuesCategorized.append(self.retailVenues)

            DispatchQueue.main.async {
                self.tableView.reloadData()
            }
            
        }


    }
    
    
/**** -------------------------------------------------------------------------------------------------------------------------
------------------------------------------------------------------------------------------------------------------------- ***/
    //HELPER FUNCTIONS
    
    //get the data from image URL
    func getImage(from url: URL, with venue: Venue) -> UIImage? {
        if let data = try? Data(contentsOf: url) {
            return UIImage(data: data)
        }
        return nil
    }
    //get the data from image URL
    func getData(from url: URL, completion: @escaping (Data?, URLResponse?, Error?) -> ()) {
        URLSession.shared.dataTask(with: url, completionHandler: completion).resume()
    }

    //all logic that handles the displaying of correct venue opening times; returns a string that is the content of the opening times label
    func getTimes(venue : Venue) -> String {
        let today = Date()
        let dateFormatter = DateFormatter()
        var textLabel : String = ""
        textLabel = "CLOSED TODAY"
        dateFormatter.dateFormat = "yyy-MM-dd"
        let todayString = dateFormatter.string(from: today)
        if let dateHours = venue.dateHours {
            for dateHour in dateHours{
                let date = dateHour.date
                let meal = dateHour.meal
                //handles the three options of display times
                if (date == todayString) {
                    //option 1: no times open
                    if(meal.count == 0){
                        textLabel = "CLOSED TODAY"
                        //option  2: one range of time open
                    }else if(meal.count == 1){
                        textLabel = ""
                        //extract only the hour portion, convert to 12-hour system
                        let open = meal[0].open.prefix(2)
                        let close = meal[0].close.prefix(2)
                        var openInt : Int = Int(open)!
                        var closedInt : Int = Int(close)!
                        if(openInt > 12){
                            openInt = openInt - 12
                        }
                        if(closedInt > 12){
                            closedInt = closedInt - 12
                        }
                        if(openInt < 12){
                            textLabel = textLabel + String(openInt) + "AM" + "-" + String(closedInt) + "PM"
                        }
                        if(openInt >= 12){
                            textLabel = textLabel + String(openInt) + "PM" + "-" + String(closedInt) + "PM"
                        }
                        //option 3: multiple ranges of times open (at most has 3)
                    }else if(meal.count == 2){
                        textLabel = ""
                        var count : Int  = 0
                        for mealTime in meal {
                            count = count + 1
                            let open = mealTime.open.prefix(2)
                            let close = mealTime.close.prefix(2)
                            var openInt : Int = Int(open)!
                            var closedInt : Int = Int(close)!
                            if(openInt > 12){
                                openInt = openInt - 12
                            }
                            if(closedInt > 12){
                                closedInt = closedInt - 12
                            }//don't want the "|" after last time range
                            if(count < meal.count){
                                textLabel = textLabel + String(openInt) + "-" + String(closedInt) + " | "
                            }else{
                                textLabel = textLabel + String(openInt) + "-" + String(closedInt)
                            }
                            
                        }
                    }else{
                        textLabel = ""
                        var count : Int  = 0
                        for mealTime in meal {
                            count = count  + 1
                            let open = mealTime.open.prefix(2)
                            let close = mealTime.close.prefix(2)
                            var openInt : Int = Int(open)!
                            var closedInt : Int = Int(close)!
                            if(openInt > 12){
                                openInt = openInt - 12
                            }
                            if(closedInt > 12){
                                closedInt = closedInt - 12
                            }
                            if(count < meal.count){
                                if(mealTime.type != "Closed"){//don't want to display closed times
                                    textLabel = textLabel + String(openInt) + "-" + String(closedInt) + " | "
                                }
                            }else{
                                if(mealTime.type != "Closed"){//don't want to display closed times
                                    textLabel = textLabel + String(openInt) + "-" + String(closedInt)
                                }
                            }
                        }
                    }
                }
            }
            

        }
        return textLabel
    }
    
    //-------------------------------------------------------------------------------------------------------------------------
    //-------------------------------------------------------------------------------------------------------------------------
    ///TABLE VIEW FUNCTIONS

    override func numberOfSections(in tableView: UITableView) -> Int {
        //one section for Retail Dining, one section for Dining Halls
        return 2
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        //categorize into retail or dining hall

        print("Venues Categorized")
        print(venuesCategorized)
        
        //number of rows in each dining section
        if(venuesCategorized.count == 2) {
            return self.venuesCategorized[section].count
        }
        return 0
        
    }

    // Create a standard header that includes the returned text.
    override func tableView(_ tableView: UITableView, titleForHeaderInSection
        section: Int) -> String? {
        if(section == 0){
            return "Dining Halls"
        }else{
            return "Retail Dining"
        }
        
    }
    
    
    
    override func tableView(_ tableView: UITableView, willDisplayHeaderView view: UIView, forSection section: Int) {
        
        view.tintColor = UIColor(red: 0.967, green: 0.985, blue: 0.998, alpha: 1)
        
        var header : UITableViewHeaderFooterView = view as! UITableViewHeaderFooterView
        header.textLabel?.font = UIFont.boldSystemFont(ofSize: 30)
        
    }
    
    
    //Populates each cell with relevant dining information
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let diningCell = tableView.dequeueReusableCell(withIdentifier: "diningCell", for: indexPath) as! diningCell
        

        if(venuesCategorized.count != 0){
            //venue name
            diningCell.venue.text = self.venuesCategorized[indexPath.section][indexPath.row].name
            //display open times
            if (getTimes(venue: self.venuesCategorized[indexPath.section][indexPath.row]) != "CLOSED TODAY") {
                diningCell.times.text = "OPEN: " + getTimes(venue: self.venuesCategorized[indexPath.section][indexPath.row])
                diningCell.times.textColor = UIColor(red: 0.01, green: 0.3, blue: 0.9, alpha: 1)
            } else {
                diningCell.times.text = getTimes(venue: self.venuesCategorized[indexPath.section][indexPath.row])
                diningCell.times.textColor = UIColor(red: 0, green: 0, blue: 0, alpha: 1)
            }
            
            
            
            //handle uploading image
            if let imageURLString = self.venuesCategorized[indexPath.section][indexPath.row].imageURL,
                let imageURL = URL(string : imageURLString) {
                getData(from: imageURL) { data, response, error in
                    guard let data = data, error == nil else {print(error); return }
                    print(response)
                    print("Download Finished")
                    DispatchQueue.main.async() {
                        //caching with KingFisher library
                        diningCell.venueImage.kf.setImage(with: imageURL)
                        //diningCell.venueImage.image = UIImage(data: data)
                        diningCell.venueImage.layer.cornerRadius = 8.0
                        diningCell.venueImage.clipsToBounds = true
                    }
                }
            }
            
        }
        
        return diningCell
    }
    
    
//prepares segue to web view controller, passing in the facilityURL that corresponds to venue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
        if segue.identifier == "showWebView"{
            let nextScene = segue.destination as? WebViewController
            let indexPath = self.tableView.indexPathForSelectedRow
            let selectedVenue = venuesCategorized[(indexPath?.section)!][(indexPath?.row)!]
            let facilityURL = selectedVenue.facilityURL
            nextScene?.facilityURL = facilityURL
        }
    }
    
    func jsonData() {
        
    

    }
    

}
