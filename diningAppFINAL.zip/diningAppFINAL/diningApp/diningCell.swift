//
//  UITableViewController.swift
//  diningApp
//
//  Created by Angela Lin on 9/20/20.
//  Copyright © 2020 Angela Lin. All rights reserved.
//

import UIKit

class diningCell: UITableViewCell {
    
    @IBOutlet weak var venueImage: UIImageView!

    @IBOutlet weak var times: UILabel!
    
    @IBOutlet weak var venue: UILabel!
    
    @IBOutlet weak var status: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        
        venue.sizeToFit()
        venue.numberOfLines = 3
        
        
    
        NSLayoutConstraint.activate([

            venueImage.widthAnchor.constraint(equalToConstant: 100),
                    venueImage.heightAnchor.constraint(equalToConstant: 78.5),
            venueImage.centerYAnchor.constraint(equalTo: contentView.centerYAnchor),
            ])
        venue.setContentCompressionResistancePriority(UILayoutPriority.defaultHigh, for: .horizontal)
        venue.adjustsFontSizeToFitWidth = true


    }

}
