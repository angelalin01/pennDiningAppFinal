//
//  NetworkManager.swift
//  diningApp
//
//  Created by Angela Lin on 9/19/20.
//  Copyright © 2020 Angela Lin. All rights reserved.
//

import Foundation

class NetworkManager {
    
    //makes network call to the given API
    static func networkRequest(completion: @escaping ([Venue]) -> Void){
        let url = URL(string: "https://api.pennlabs.org/dining/venues")
        let session = URLSession(configuration: URLSessionConfiguration.default)
        
        let task = session.dataTask(with: url!) { (data, response, error) in
            print(data)
            guard (error == nil) else {
                print(error!.localizedDescription)
                return
            }
            
            guard let status = (response as? HTTPURLResponse)?.statusCode, status == 200 else {
                print("Not 200 response code")
                return
            }
            
            if let venues = Venue.dataToVenues(data){
                completion(venues)
            }else{
                print("Error")
            }
            
        }
        task.resume()
    }
    

}
