//
//  WebViewController.swift
//  diningApp
//
//  Created by Angela Lin on 9/21/20.
//  Copyright © 2020 Angela Lin. All rights reserved.
//

import UIKit
import Foundation
import WebKit

class WebViewController: UIViewController, WKUIDelegate {
    var facilityURL : String = ""
    @IBOutlet var webView:  WKWebView!
    
    //configures web view
    override func loadView() {
        let webConfiguration = WKWebViewConfiguration()
        webView = WKWebView(frame: .zero, configuration: webConfiguration)
        webView.uiDelegate = self
        view = webView
    }
    
    //loads the facility URL passed in from last view controller
    override func viewDidLoad(){
        super.viewDidLoad()
        
        let myURL = URL(string: facilityURL)
        let myRequest = URLRequest(url: myURL!)
        webView.load(myRequest)

    }
}

