//
//  Venue.swift
//  diningApp
//
//  Created by Angela Lin on 9/20/20.
//  Copyright © 2020 Angela Lin. All rights reserved.
//

import Foundation

//represents the hierarchy of the API data
struct docWrapper: Decodable {
    let document : venueWrapper
}

struct venueWrapper: Decodable {
    let venue: [Venue]
}

struct Venue: Decodable{
    
    struct Meal : Decodable {
        let close : String
        let open : String
        let type : String
    }
    
    struct DateHour : Decodable {
        let meal : [Meal]
        let date : String
    }

    var name : String
    var dailyMenuURL : String
    var weeklyMenuURL : String
    var dateHours : [DateHour]?
    var facilityURL : String
    var imageURL : String?
    var id : Int
    var venueType : String 
    
    //returns an array of Venues from the fetched data using JSONDecoder to decode the data
    static func dataToVenues(_ data : Data?) -> [Venue]? {
        print("dataToVenues")
        print(data)
        guard let data = data else {
            print("Error: Nothing to decode")
            return nil
        }
        let decoder = JSONDecoder()
        do {
           let decodedVenues1 = try? decoder.decode(docWrapper.self, from: data)
            print("decoded venues")
            print(decodedVenues1)
        } catch let error {
            print("error")
            print(error)
        }
        guard let decodedVenues = try? decoder.decode(docWrapper.self, from: data) else {
            print("Error: Unable to decode venues data to Venues")
            return nil
        }
        print(decodedVenues.document.venue)
        print("Success")
        
        return decodedVenues.document.venue
    }
}


