//
//  UITableViewCell.swift
//  diningApp
//
//  Created by Angela Lin on 9/20/19.
//  Copyright © 2019 Angela Lin. All rights reserved.
//

import UIKit

class UITableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
